.pragma library

function get_current_day() {
    var today = new Date();
    var dd = today.getDate();

    return dd;
}
